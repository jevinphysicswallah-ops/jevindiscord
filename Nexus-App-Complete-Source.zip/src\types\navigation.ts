export type UserStatus = 'online' | 'idle' | 'dnd' | 'offline';

export interface UserProfile {
  id: string;
  name: string;
  username: string;
  avatar: string;
  status: UserStatus;
  customStatus?: string;
  role: string;
  isMuted: boolean;
  isDeafened: boolean;
}

export interface Workspace {
  id: string;
  name: string;
  acronym: string;
  icon?: string;
  color: string;
  unreadCount?: number;
  hasMention?: boolean;
  description: string;
  role: string;
  membersCount: number;
}

export interface NavItem {
  id: string;
  title: string;
  route: string;
  iconName: string;
  badge?: number | string;
  isPinned?: boolean;
  isVoiceLounge?: boolean;
  isLocked?: boolean;
  description?: string;
}

export interface NavCategory {
  id: string;
  name: string;
  collapsible?: boolean;
  isCollapsed?: boolean;
  items: NavItem[];
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  unread: boolean;
  avatar?: string;
  workspaceName?: string;
  type: 'mention' | 'announcement' | 'task' | 'system';
}

export interface BreadcrumbItem {
  label: string;
  route?: string;
}
